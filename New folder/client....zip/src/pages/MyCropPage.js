import { React, useState } from "react";
import "../css/myCropPage.css";
import "../css/predictionPage.css";
import { cropData } from "../Assets/cropImages/Data";

export default function MyCropPage() {
  const [pageNo, setPageNo] = useState(1);
  const [crop, setcrop] = useState("");
  const [landArea, setLanarea] = useState();

  const changePage = (value) => {
    setPageNo(value);
  };

  const getlandArea = (value) => {
    setLanarea(value);
    console.log(landArea);
  };
  const takecrop = (event) => {
    setcrop(event.currentTarget.id);
  };
  return (
    <div className="myCropPage">
      <h2>My Crop</h2>

      {(() => {
        switch (pageNo) {
          case 1:
            return (
              <FirstPage
                changePage={changePage}
                crop={crop}
                takecrop={takecrop}
              />
            );
          case 2:
            return (
              <SecondPage
                changePage={changePage}
                getlandArea={getlandArea}
                crop={crop}
              />
            );
          case 3:
            return <ThirdPage landArea={landArea} />;
          default:
            return null;
        }
      })()}
    </div>
  );
}

function FirstPage(props) {
  const { changePage, crop, takecrop } = props;

  return (
    <div className="firstPage">
      <img src={require("../Assets/mycropImg.png")} alt="" className="mcrFG" />
      <div className="cropList">
        {cropData.map((x) => (
          <div className="listitem" id={x.cropName} onClick={takecrop}>
            <div className="crpImg">
              <img src={x.path} alt="" />
            </div>
            <div className="crName">{x.cropName}</div>
          </div>
        ))}
      </div>
      <div className="selectedCrop">{"Selected Crop : - " + crop}</div>
      <button onClick={() => changePage(2)}>Next Step</button>
    </div>
  );
}

function SecondPage(props) {
  const { changePage, getlandArea, crop } = props;
  const [area, setAreavalue] = useState(0);

  const [geolocation, setGeolocation] = useState(false);
  const [totalBudget, setBudget] = useState(0);
  const [production, setProduction] = useState(0);
  const [profit, setProfit] = useState(0);
  const [demand, setdemand] = useState(false);
  const [show, setshow] = useState(false);

  const cropInfo = cropData.find((entry) => entry.cropName === crop);

  const calculateBudget = () => {
    setshow(true);
  };

  return (
    <div className="secondPage">
      <div className="listitem">
        <div className="crpImg">
          <img src={cropInfo.path} alt="" />
        </div>
        <div className="crName">{crop}</div>
      </div>
      <div className="inputBlock">
        Land Area in Acre :
        <input
          type="number"
          name="Land-Area"
          id="landArea"
          onChange={(e) => setAreavalue(e.target.value)}
        />
      </div>

      <button
        onClick={() => {
          getlandArea(area);
          calculateBudget();
        }}
      >
        Calculate Budget
      </button>

      <div
        style={{
          display: show ? "block" : "none",
          width: "90%",
          
          marginTop:'-20px'
        }}
      >
        <h5>Total Crop production &nbsp;&nbsp;&nbsp;&nbsp;: {production}</h5>
        <h5>Total Harvesting Budget &nbsp;: {totalBudget}</h5>

        {geolocation ? (
          <h6 style={{color:'red'}}>
            Not recommended as your loaction is not suitable for this crop..
            <button onClick={() => changePage(1)} className="redbtn">
              Choose Crop
            </button>
          </h6>
        ) : (
          <>
            {demand ? (
              <h5>
                Total Predicted Profit : {profit}{" "}
                <button onClick={() => changePage(3)} className="greenbtn">
                  Create Virtual Farm
                </button>
              </h5>
            ) : (
              <h5>
                Demand is low select another crop..{" "}
                <button onClick={() => changePage(3)} className="yellowbtn">
                  Create Virtual Farm
                </button>
              </h5>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function ThirdPage(props) {
  const { landArea } = props;
  return <div className="thirdPage">{landArea}</div>;
}
