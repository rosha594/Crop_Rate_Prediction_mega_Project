const userData = [{
    mobileNO:"8329289579",
    user_Name:"Roshan Bende",
    district_:"Nagpur",
    userCity:"Nagpur",
    password:"123456"
},
{
mobileNO:"8329289589",
user_Name:"Shreya Pokale",
district_:"Wardha",
userCity:"Aarvi",
password:"123456"
},
{
    mobileNO:"8329289599",
    user_Name:"Pallavi Shankarpale",
    district_:"Wardha",
    userCity:"Deori",
    password:"123456"
    },
    {
        mobileNO:"8329289569",
        user_Name:"Ashis Bopche",
        district_:"Amaravati",
        userCity:"Bhil Gaon",
        password:"123456"
        },
        {
            mobileNO:"8329289519",
            user_Name:"Manish Bokade",
            district_:"Nanded",
            userCity:"Nanded",
            password:"123456"
            },
]


export {userData}