import React from 'react'
import '../css/predictionPage.css'

export default function CropPriceResult(props) {
 const {state} = props;
 
  return (
    <div className='cropPriceResult'>
      
      <table>
        <tr>
          <th>District</th>
          <th>Market</th>
          <th>Date</th>
          <th>Price</th>
          
        </tr>
        <tr>
          <td>{state.crop}</td>
          <td>Kalamana Market</td>
          <td>18/04/2023</td>
          <td>2210 /-</td>          
        </tr>
        <tr>
          <td>Nagpur</td>
          <td>Kampthee Market</td>
          <td>18/04/2023</td>
          <td>2220 /-</td>          
        </tr>
        <tr>
          <td>Nagpur</td>
          <td>Cotton Market</td>
          <td>18/04/2023</td>
          <td>2210 /-</td>          
        </tr>
      </table>
    </div>
  )
}
