import React from 'react'
import '../css/mainBlock.css'
import MainArea from '../components/MainArea'
import UserArea from '../components/UserArea'
export default function MainBlock() {
  return (
    <div className='mainBlock'>
      <UserArea/>
      <MainArea/>
    </div>
  )
}
