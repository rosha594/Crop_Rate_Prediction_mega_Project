const preData = [
    {
        cropName:"Arhar",
        district:[
            {
                distName:"Nagpur",
                markets:[
                    {
                        marName:"Cotton Market",
                        date:[
                            {
                                day:"2023-05-18",
                                price:"6600"
                            },
                            {
                                day:"19/05/2023",
                                price:"6630"
                            },
                            
                            {
                                day:"2024-05-17",
                                price:"6700"
                            },


                        ]
                    },
                    {
                        marName:"Kalamana Market",
                        date:[
                            {
                                day:"2023-05-18",
                                price:"6600"
                            },
                            {
                                day:"19/05/2023",
                                price:"6630"
                            },
                            
                            {
                                day:"17/05/2024",
                                price:"6700"
                            },


                        ]
                    },
                ]
            },
        ]
    },
]

export {preData}