const guidData=[
    {
        cropName:"Arhar",
        season:"Kharif",
        guidance:[
            {
                info:"general Info",
                temperature:"..",
                sowingTemperature:"..",
                rainfall:"..",
                harvestingTemperature:"..",
                soilReuired:"grown on well drained loamy to sandy-loam soils",
                timeOfsowing:"first fort of night of July",
                spacing:"row spacing 30cm and plant spacing 10cm",
                spaingDepth:"4-6cm",
                seedRate:"8-9kg/Acre",
                fertilizer1:"Urea 12kg + SSP 100kg/Acer",
                fertilizer2:"Nitrozen 5kg + Phosphorus 16kg/Acre"
            },
        ]
    }
]